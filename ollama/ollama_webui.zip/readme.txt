Installer Docker Desktop avec WSL

Ouvrir ce dossier avec un CMD

Executer la commande suivante : docker compose up -d

Ouvrir un navigateur à la page suivante : localhost:3000